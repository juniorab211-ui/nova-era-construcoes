# NOVA ERA CONSTRUÇÕES LIMITADAS — primeira versão editável

Esta é uma versão inicial da loja, em português, com identidade verde e roxa, catálogo sem carrinho e pedidos diretos por WhatsApp.

## Como testar
Abra `index.html` num navegador. Os produtos e as alterações ficam guardados no armazenamento local desse navegador.

## Administração
Na secção “Área de administração”, a palavra-passe inicial é `NovaEra2026!`.
**Antes de publicar:** altere `ADMIN_PASSWORD` no ficheiro `index.html`. Esta autenticação é apenas de demonstração e não protege uma loja pública.

## Limitações importantes
- Os dados ficam apenas no navegador/dispositivo onde foram editados; não sincronizam entre iPhone, Android e Windows.
- Fotografias carregadas ficam guardadas localmente no navegador.
- Para publicar uma loja real com administração segura e dados partilhados, é necessário implementar autenticação no servidor, ligar uma base de dados (por exemplo Neon) e armazenamento de imagens (por exemplo Vercel Blob), configurar as variáveis secretas e fazer o deploy.
- Esta pasta ainda não está ligada à Vercel/GitHub e não foi publicada.

## Dados comerciais incluídos
- WhatsApp: +239 9022036
- Morada: Rua Patrício Lumumba, São Tomé
- Moeda: STN
